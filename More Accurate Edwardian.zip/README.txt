NOTE: Only Fallout: Who Vegas is required, but I STRONGLY recommend getting Xoanon's Additons & Fixes,

along with Spyduck's Theme Updates.


Be sure to only have one enabled until you enter the TARDIS, though, otherwise there'll be conflicts.

Addtionally, be sure to install this LAST over any other FWV mod that edits the same NIF files of the 1996 Interior.


Installation:

- Unzip the contents in the download using 7-Zip or another program like it.

- Copy the Data folder over to your Fallout New Vegas directory.