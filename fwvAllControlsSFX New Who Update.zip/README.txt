
Installation:


- Copy & paste or drag the Data folder you'll have extracted using 7-Zip to your Fallout: New Vegas directory.

- When in your Mod Manager:

	- Load fwvAllControlsSFX.esp after any of Xoanon's .esp's & also Spyduck's Theme Updates.esp.


Otherwise, have fun!




Changelog:

Initial Release:

	- What's the name of this addon, I forget.



Classic Who Update:

- Made Xoanon.esm & Xoanon.esp as masters to add SFX to the Fault Locators & Fast-Return Switches added by them.

- Added SFX to:

	- All controls that didn't have SFX in the Retro, Classic, & Rani Console Rooms
	   besides their Fault Locators & Telepathic Circuits.

		- Used Vanilla SFX & base FWV SFX.

	- Fault Locator in Edwardian Console Room.

	- All Fast-Return Switches (thankfully, there's only 3 repeated all through the Consoles).

	- Miscellanous controls that look like buttons throughout all Consoles.

- Attempted adding SFX to the Astronav, probably makes the sound when it's actually used in Space-Flight.

	If not, ¯\_(ツ)_/¯



New Who Update:

- Switched around existing SFX in Classic & Retro Console Rooms to avoid too noticeable dupe sounds.

- Removed "Chameleon Arch" Script from Classic's Telepathic Circuits to avoid people accidentally using it.

- Added SFX to:

	- All controls that didn't have SFX in the Glitch, Coral, Copper, & Toyota Console Rooms.

		- Only vanilla SFX is for Gyroscopic Stabiliser in Toyota, & all Radio Dials.

		- Includes all Promixity Scanners/Alarms/Detectors/whatever; Misc. Controls; & Telepathic Circuits.

- Added an easter egg in Copper. What can you use to hear music?


SFX that's in the controls2005 folder was isolated by me, the rest wasn't, nor is it mine.

Some SFX was composited. Try to guess which ones, if you want!

All other SFX came from these sources, all on YouTube:

	- Tardis Sound Effects.

	- thatSFXguy.

	- TARDIS SFX.

	- Doctor Who 50th Anniversary Boxset - 11CD Edition.


All Doctor Who-related assets belong to the BBC, while the composited Switch sounds for the Misc. Switches come from Picture to Sound.com


Check out Picture to Sound here:

Sound effects by https://picturetosound.com
Youtube: https://www.youtube.com/c/picturetosound


Doctor Who Theme Arrangement by Delia Derbyshire.

