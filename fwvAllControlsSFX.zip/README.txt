
Installation:


- Copy & paste or drag the Data folder you'll have extracted using 7-Zip to your Fallout: New Vegas directory.

- When in your Mod Manager:

	- Load fwvAllControlsSFX.esp after any FWV mods that edit the sound paths for the controls.

- I recommend loading it after any of Xoanon's .esp's, & also Spyduck's Theme Updates.esp.


Otherwise, have fun!